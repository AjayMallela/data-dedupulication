package Action;
public class Block {
	public int id;
	public String data;
	public String sig;
	public Block(int id, String data, String sig) {
		super();
		this.id = id;
		this.data = data;
		this.sig = sig;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getSig() {
		return sig;
	}
	public void setSig(String sig) {
		this.sig = sig;
	}
public String toString()
	{
		return id+"-"+data+"-"+sig;
		
	}
	
}

package Action;
import java.util.*;
import java.sql.*;
public class BlockChainFac
{
public static void updateBCSig()
{
	try{
              Connection con = Dbcon.getCon();
                                Statement st = con.createStatement();
                                String query1 = "select * from upload";
		ResultSet rs1 = st.executeQuery(query1);
		TreeMap<Integer,Block> blockchain=new TreeMap<Integer,Block>();
		
		
		int i=0;
		String p="000000"; 
                                while (rs1.next()) {
                                    	int did= rs1.getInt("id");
			String file= rs1.getString("filename");
			String data= rs1.getString("data");
			String bSig=data.hashCode()+"";
			
		Block b=new Block(did,file,p);
		blockchain.put(i,b);
		p=bSig;
		i++;
                                    }
st.execute("delete from  BlockChain");

		Block bx=blockchain.get(0);
		bx.setSig(p);
		blockchain.put(0,bx);
		for(int ki:blockchain.keySet())
		{
		Block b=blockchain.get(ki);
st.execute("INSERT INTO BlockChain(id,DataName,bSignature) VALUES("+b.getId()+",'"+b.getData()+"','"+b.getSig()+"')");
System.out.println(b);
		}
		}catch(Exception ex){System.out.println(ex);}
}
}